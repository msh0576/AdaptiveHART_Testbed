#ifndef BASICSB_H
#define BASICSB_H

#define UQ_TEMPDEVICE "TempDeviceP.Resource"
#define UQ_TEMPDEVICE_STREAM "TempDeviceStreamP.Resource"

#define UQ_PHOTODEVICE "PhotoDeviceP.Resource"
#define UQ_PHOTODEVICE_STREAM "PhotoDeviceStreamP.Resource"


#endif
