README for apps/tests/deluge/GoldenImage
Author/Contact:

Chieh-Jan Mike Liang <cliang4@cs.jhu.edu>
Razvan Musaloiu-E. <razvanm@cs.jhu.edu>

Description:

This is a sample application for Deluge T2. The application is similar 
to Null, but it includes Deluge T2. The Makefile includes the
DELUGE_LIGHT_BASESTATION flag to allow the nodes to be pinged using
tos-deluge.

Prerequisites:

Python 2.4 with pySerial

References:

The Deluge T2 wiki page from http://docs.tinyos.net/
